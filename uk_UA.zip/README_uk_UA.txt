This is Ukrainian spelling dictionary for myspell & hunspell version 1.5.7.

This dictionary based on spell-uk project http://ispell-uk.sourceforge.net/


Copyright (C) 1999
    Vladimir Yakovchuk
    Oleg Podgurniy
    
Copyright (C) 2001 
    Dmytro Kovalyov
    Maksym Polyakov
    Andriy Rysin

Copyright (C) 2002
    Valentyn Solomko
    Volodymyr M. Lisivka
    
Copyright (C) 2005
    Andriy Rysin
    Eugeniy Meshcheryakov
    Dmytro Kovalyov

Copyright (C) 2006-2009
    Andriy Rysin

This dictionary is licensed under GPL, LGPL and MPL (Mozilla Public License) licenses.
